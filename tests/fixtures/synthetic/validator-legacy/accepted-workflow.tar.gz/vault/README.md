Helseark archive format 1. Accepted JSON is authoritative.
Do not edit accepted history. Staging is unpublished and ignored.
Offline baseline validation and schema export are available; imports still require a reviewed publication workflow.
Copy this whole folder while no writer is active to retain definitions and history.
